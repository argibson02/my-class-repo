# 📐 Scraping into a DB Review

Work with a partner to review the functionality of the code found in [Unsolved](./code-review).

## Review Scraping into a DB

### Instructions

Review the following

* server.js


---

## 📝 Notes


Use [Google](https://www.google.com) or another search engine to research this.

---
© 2021 Trilogy Education Services, LLC, a 2U, Inc. brand. Confidential and Proprietary. All Rights Reserved.
